package mob.lab.search.Adapter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.image_rv.view.*
import mob.lab.search.R
import mob.lab.search.networking.Fact

class ImgAdapter (
    private val Images: List<Fact> = emptyList(),
    private val onImageClick: (Fact) -> Unit
):RecyclerView.Adapter<ImgAdapter.ItemViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ItemViewHolder(LayoutInflater.from(parent.context)
            .inflate(R.layout.image_rv, parent, false))

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bindImage(fact = Images[position])
//        Picasso.get().load(Images[position].webformatURL).into(holder.itemView.image_row)
    }

    override fun getItemCount() = Images.size

    inner class ItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {

        fun bindImage(fact: Fact) {
            Picasso.get().load(fact.image).into(view.image_row)

            view.setOnClickListener{
                onImageClick(fact)
            }
        }
    }
}

//fun bindImage(image: com.example.imagesearch.networking.Image) {
//    Picasso.get().load(image.webformatURL).into(view.image_view)
//
//}