package mob.lab.search.networking

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FactsLoader (
        private val onSuccess:(FactResponse) -> Unit,
        private val onError: (Throwable) -> Unit
) {

    fun loadFacts(q: String) {
        ApiFactory.getApiClient()
            .getAllFacts(q= q)
            .enqueue(object : Callback<FactResponse> {
                override fun onResponse(
                    call: Call<FactResponse>,
                    response: Response<FactResponse>
                ) {

                onSuccess(response.body()!!)
                }

                override fun onFailure(call: Call<FactResponse>, t: Throwable) {
                    onError(t)

                }
            })
    }
}