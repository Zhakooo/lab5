package mob.lab.search

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.EditText
import android.widget.SearchView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import mob.lab.search.Adapter.ImgAdapter
import mob.lab.search.networking.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViews()
    }
        private fun setupViews() {
            imgRV.layoutManager = LinearLayoutManager(this)

//            imgRV.adapter = ImgAdapter(Images = imageList,
//                onImageClick = {clicked_image ->
//                                    })
            imgET.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

                override fun onQueryTextChange(newText: String): Boolean {
                    return false
                }

        override fun onQueryTextSubmit(query: String): Boolean {
            FactsLoader(
                onSuccess = {
                    val Images = it.hits

                    imgRV.adapter = ImgAdapter(
                        Images,
                onImageClick = {next_image ->
                        Picasso.get().load(next_image.image).into(fullscreen_image)
                        fullscreen_image.visibility = View.VISIBLE
                        imgRV.visibility = View.INVISIBLE
                        fullscreen_image.setOnClickListener {
                            fullscreen_image.visibility = View.INVISIBLE
                            imgRV.visibility = View.VISIBLE
                }})},
                onError = {
                    Toast.makeText(applicationContext, it.toString(), Toast.LENGTH_LONG).show()

                }).loadFacts(query)
            return true
        }
    } )}}


