package mob.lab.search.networking

import com.google.gson.annotations.SerializedName


data class Fact(
    val id: String,
    @SerializedName("webformatURL") val image:String
//    val tags:String,
//    val likes: Int
)

data class FactResponse(
    val hits: List<Fact>
)